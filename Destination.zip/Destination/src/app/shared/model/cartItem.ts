import { Destinations } from "./destination";


export class CartItem{
   
constructor(destination:Destinations){
    this.destination = destination;

}

    destination:Destinations;
    quantity:number = 1;
    get price():number{
        return this.destination.price * this.quantity;
    }
}

