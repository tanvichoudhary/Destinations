export class Destinations{
    id!:number;
    price!:number;
    name!:string;
    favourite:boolean=false;
    star!:number;
    tags?:string[];
    imageUrl!:string;
    bestMonth!:string;
    places!:string[];

}