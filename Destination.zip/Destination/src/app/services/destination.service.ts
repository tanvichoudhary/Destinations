import { Injectable } from '@angular/core';
import { Destinations } from 'src/app/shared/model/destination';
@Injectable({
  providedIn: 'root'
})
export class DestinationService {

  constructor() { }
  getDestinationById(id:number):Destinations {
    return this.getAll().find(destination => destination.id == id)!;
  }
  
  getAll(): Destinations[] {
    return [
      {
        id: 1,
        name: 'Bali',
        bestMonth: 'November',
        price: 800,
        favourite: true,
        places: ['Tanah Lot Temple', 'Bali Zoo'],
        star: 3.3,
        imageUrl: '/assets/Bali.jpg',
        tags: ['Beaches', 'Temple']
      },
      {
        id: 2,
        name: 'Santorini, Greece',
        bestMonth: 'June',
        price: 5000,
        favourite: true,
        places: ['Santo Winery','Amoudi Bay'],
        star: 4.2,
        imageUrl: '/assets/Greece.jpg',
        tags: ['Wineries, Beaches']
      },
      {
        id: 3,
        name: 'Rome, Italy',
        bestMonth: 'April',
        price: 6000,
        favourite: true,
        places: ['italy'],
        star: 3.3,
        imageUrl: '/assets/Rome.jpg',
        tags: ['FastFood', 'fry'],
      },
      {
        id: 4,
        name: 'Zurich, Swtizerland',
        bestMonth: 'June',
        price: 8000,
        favourite: true,
        places: ['Lindt Home of Chocolate Museum','Mount Titlis'],
        star: 3.3,
        imageUrl: '/assets/Switzerland.jpg',
        tags: ['Chocolates', 'Swiss'],
      },

      {
        id: 5,
        name: 'Jaipur, India',
        bestMonth: 'November',
        price: 1000,
        favourite: true,
        places: ['Amber Fort','Hawa Mahal', 'Jal Mahal'],
        star: 3.3,
        imageUrl: '/assets/Jaipur.jpeg',
        tags: ['Pink City', 'Palaces'],
      },

      {
        id: 6,
        name: 'Seoul, South Korea',
        bestMonth: 'March',
        price: 5000,
        favourite: true,
        places: ['Lotte World', 'Han River', 'N Seoul Tower'],
        star: 3.3,
        imageUrl: '/assets/Seoul.jpg',
        tags: ['Cherry Blossom', 'BTS'],
      }


    ];
  }

}


