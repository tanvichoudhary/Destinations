import { Injectable } from '@angular/core';
import { Destinations } from '../shared/model/destination';
import { Cart } from '../shared/model/cart';


@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cart:Cart = new Cart();

  addToCart(destination:Destinations){
    console.log(destination+" inside serv destination displayed");
   
     let CartItem = this.cart.items.find(item => item.destination.id == destination.id)
     console.log(CartItem+" inside service Mtd");
   
     if (CartItem){
       this.changeQuantity(destination.id , CartItem.quantity +1)
     
      return;
    }
  //  this.cart.items.push(new CartItem(food));
  }
  removeFromCart(destinationId:number):void{
    this.cart.items = this.cart.items.filter(item =>item.destination.id !=destinationId)
  }
  changeQuantity(quantity:number , destinationId:number){
    let cartItem = this.cart.items.find(item=>item.destination.id == destinationId);
    if(!cartItem) return;
    cartItem.quantity = quantity;
  }
  getCart():Cart{
    console.log(this.cart);
   
    return this.cart;
  }


  

  constructor() { }
}
