import { Component, OnInit } from '@angular/core';
import { DestinationService } from '../services/destination.service';
import { Destinations } from 'src/app/shared/model/destination';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  destinations:Destinations[]=[];
  constructor(private ds:DestinationService,private router:ActivatedRoute){}

  ngOnInit(): void {
    
    
    this.router.params.subscribe(param=>{
      if(param['searchItem'])
      this.destinations = this.ds.getAll().filter(destination=>destination.name.toLowerCase().includes(param['searchItem'].toLowerCase()))
      else
      this.destinations = this.ds.getAll();
    })
    
    
    
  }

}
