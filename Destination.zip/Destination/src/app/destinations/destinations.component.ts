import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { Destinations } from 'src/app/shared/model/destination';
import { DestinationService } from '../services/destination.service';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-destinations',
  templateUrl: './destinations.component.html',
  styleUrls: ['./destinations.component.css']
})
export class DestinationsComponent implements OnInit {
  destination!:Destinations
  cartService: any;
  constructor(private activatedRoute:ActivatedRoute , private destinationServices:DestinationService,privatecartService:CartService, private router:Router){
    activatedRoute.params.subscribe((params)=>{
      if(params['id'])
      this.destination = destinationServices.getDestinationById(params['id'])
    })
  }

  ngOnInit(): void {
   
  }

  addToCart(){
    this.cartService.addToCart(this.destination);
    console.log(this.destination);
   
    // this.router.navigateByUrl('/cart-page')
  }
}
 


